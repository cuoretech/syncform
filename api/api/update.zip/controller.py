from api.user_model import *
# from views import*
data = dict(single_result)
data.update(single_result2)
data.update(single_result3)
data.update(single_result4)
data.update(single_result5)
data.update(single_result6)
data.update(single_result7)
data.update(single_result8)
data.update(single_result9)

full_results = dict(results)
full_results.update(results2)
full_results.update(results3)
full_results.update(results4)
full_results.update(results5)
full_results.update(results6)
full_results.update(results7)
full_results.update(results8)
full_results.update(results9)


